package io.seata.samples.shardingsphere.modules.service;


public interface IBusinessService {
    void purchase();
}
