# dubbo

How to use Seata to ensure consistency between Dubbo Microservices ？  

Please see the blog:   
Engligh: http://dubbo.apache.org/en-us/blog/dubbo-fescar.html   
中   文: http://dubbo.apache.org/zh-cn/blog/dubbo-fescar.html
